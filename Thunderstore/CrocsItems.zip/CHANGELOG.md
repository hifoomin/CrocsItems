# 1.1.0 Patch Notes
- Updated README
- Added range indicator to Crocs Sandals
- Buffed Crocs Classic Offensive Stance to also provide 20% movement speed
- Nerfed Black Heart Base Maximum Health Regen Percent from 1.5% to 1%
- Nerfed Black Heart Stack Maximum Health Regen Percent from 1.5% to 1%
- Nerfed Sweet Treat Base Cooldown Reduction from 15% to 12.5%
- Nerfed Sweet Treat Stack Cooldown Reduction from 15% to 12.5%
- Nerfed Crocs Sandals Base Maximum Attack Speed from 40% to 30%
- Nerfed Crocs Sandals Stack Maximum Attack Speed from 40% to 30%
- Nerfed Crocs Sandals Base Heal Percent from 1.5% to 1%
- Nerfed Crocs Sandals Stack Heal Percent from 1.5% to 1%
- Nerfed Crocs Classic Cooldown from 5s to 10s
- Nerfed Crocs Classic Armor from 50 to 30
- Nerfed Crocs Classic Bonus Healing from 50% to 40%
- Nerfed Jibbitz Drop Rate from 12% to 10%
- Fixed Crocs Classic description
- Fixed Jibbitz dropping from equipment barrels and other edge-cases
- I might add a stat config later

## 1.0.2 Patch Notes
- Updated README
- Updated mod icon

## 1.0.1
- Updated README
- Updated mod icon

## 1.0.0
- Released